<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>API Documentation</title>
    <script src="https://api.apiary.io/seeds/embed.js"></script>
    <script type="text/javascript">
    var embed = new Apiary.Embed({
      "subdomain": "warthunder",
      "preferences": {
        "defaultHost": "production"
      }
    });
    </script>
  </head>
  <body>

  </body>
</html>
